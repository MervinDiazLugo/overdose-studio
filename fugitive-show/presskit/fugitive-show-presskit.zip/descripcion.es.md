# Fugitive Show — descripción del juego

Nombre elegido el 2026-11-06 (antes "Runner Bounty"). Pendiente: búsqueda de
marca registrada antes de registrar dominios y redes. "Runner" y "Hunter"
siguen siendo los nombres de los roles dentro del juego.

## Una línea (para bios y titulares)

**ES:** Una cacería humana en vivo de 2 minutos y medio: sobrevive como Runner o caza por dinero.
**EN:** A two-and-a-half-minute live TV manhunt: survive as the Runner or hunt for cash.

## Corta (subtítulo de tienda, 30 caracteres máx.)

- ES: Cacería en vivo por dinero
- EN: Deadly live manhunt for cash

## Párrafo corto (tienda, presskit, emails)

**ES:** Fugitive Show es un juego multijugador de acción en 2D, visto desde
arriba, ambientado en un show de televisión mortal. En cada ronda, uno o dos
jugadores son los Runners y el resto son Hunters. Los Runners tienen que
sobrevivir 2:30 minutos con lo que compraron; los Hunters reaparecen una y otra
vez para atraparlos. Todos son Runner al menos una vez por partida, y gana quien
termina con la bolsa más grande. De 2 a 10 jugadores, con cross-play entre PC y
Android.

**EN:** Fugitive Show is a top-down 2D multiplayer action game set inside a
deadly TV show. Each round, one or two players are the Runners and everyone
else is a Hunter. Runners must survive two and a half minutes with whatever
they bought; Hunters keep respawning to take them down. Everyone gets a turn as
the Runner, and the biggest bankroll at the end wins. 2 to 10 players, with
cross-play between PC and Android.

## Descripción larga

**ES:** Bienvenido al estudio. El presentador ya está en el aire, las cámaras
están encendidas y el público quiere sangre. En Fugitive Show, de 2 a 10
amigos se reúnen en un estudio de televisión que se puede recorrer, eligen su
personaje y preparan sus compras sin saber todavía qué papel les va a tocar.
Entonces se revela el sorteo: uno o dos son los Runners, la estrella del
programa, con 10.000 para gastar en armas, chalecos y burbujas. Todos los
demás son Hunters, con 3.000, un arma y ganas de cobrar la recompensa.

La ronda dura 2:30. Los Runners no reaparecen: si los atrapan, su dinero se
reparte entre los Hunters. Los Hunters reaparecen al instante, pero sin su
arma, y tienen que volver a comprar. Si un Runner sobrevive, cobra el doble de
lo que no gastó. Lo que cada jugador gana pasa a su bolsa, que es su puntaje en
la partida. La rotación asegura que todos tengan su turno como estrella del
show.

El arte está dibujado a mano con la actitud de los arcades de los 90: tinta
gruesa, sombreado cel y un elenco caricaturesco donde cada personaje usa lentes
distintos. El ex convicto, el motoquero, el luchador, la novia, el carnicero, el
cowboy, el repartidor y otros recorren un wasteland donde el viento arrastra
polvo, bolsas y plantas rodadoras. Más adelante llega una ciudad cyberpunk.

**EN:** Welcome to the studio. The host is on air, the cameras are rolling and
the audience wants blood. In Fugitive Show, 2 to 10 friends gather in a
walkable TV studio, pick their character and prepare their loadouts before they
know which role they will get. Then the draw is revealed: one or two players
are the Runners, the stars of the show, with 10,000 to spend on weapons, vests
and bubble shields. Everyone else is a Hunter with 3,000, a weapon and a bounty
to collect.

Rounds last 2:30. Runners never respawn: if they are caught, their cash is
split among the Hunters. Hunters respawn instantly but lose their weapon and
have to buy again. A Runner who survives collects double what they did not
spend. Every round's winnings go into each player's bankroll, the match score.
Roles rotate, so everyone gets a turn as the star of the show.

The art is hand-drawn with a 90s arcade attitude: thick ink, cel shading and a
cartoon cast where every character wears different glasses. The ex-convict, the
biker, the luchador, the bride, the butcher, the cowboy, the delivery rider and
more roam a wasteland where the wind drags dust, plastic bags and tumbleweeds.
A cyberpunk city arrives later.

## Características

- Rondas de 2:30: partidas cortas para jugar con amigos.
- 1 o 2 Runners contra todos; los roles rotan y todos son estrella alguna vez.
- Economía de ronda: compras antes del sorteo, recompensas por bajas y bolsa
  acumulada como puntaje.
- Hunters que reaparecen al instante; Runners con una sola vida.
- Lobby que se recorre: un estudio de TV con presentador, cámaras y campo de
  prácticas para probar las armas.
- Arte dibujado a mano, estilo arcade de los 90, con un elenco caricaturesco y
  24 accesorios ridículos.
- De 2 a 10 jugadores, salas privadas con código y cross-play PC–Android.
- Sin pagar para ganar: el dinero real compra solo cosméticos.

## Datos

| Campo | Valor |
|---|---|
| Desarrollador | Mervin, desarrollador independiente en Buenos Aires, Argentina |
| Género | Acción multijugador asimétrica, party game |
| Jugadores | 2–10 en línea |
| Plataformas | PC (Steam) y Android, con cross-play; iPhone después |
| Motor | Unity |
| Estado | Prototipo jugable; prueba cerrada próximamente |
| Fecha de lanzamiento | Por anunciar |
| Precio | Por anunciar |
| Idiomas | Español e inglés previstos |
